% this code is for u'+F(u)=g0(t) solved by linear theta-method 
% you can change the functions F and dF accordingly for other problem
% the array Problem_Parameter collects the special details of your problem
clc;
clear;
current_path = fileparts(mfilename('fullpath'));
addpath(fullfile(current_path, 'Common_Functions'));

global dt T theta Nt   J alp
Nx=8;
Newton_Num=30;

alp=1e-3;
Tend=6;
dt=1/128;
theta=1/2;
Newton_Tol=1e-5; 

J=15;
DT=Tend/J;
It_GMRES_sum=zeros(3,J);
It_Newton=zeros(3,J);
Totoal_GMRES=zeros(1,3);
time_window_index=2;
fprintf('=========== time_window_index=%d =========== \n',time_window_index);
for solverP=1:3
    if solverP==1
        flag_solverP=0; 
    elseif solverP==2
        flag_solverP=2;
    else
        flag_solverP=3;
    end
    fprintf('..............solverP=%d................\n',solverP);
    T0=(time_window_index-1)*DT;T1=time_window_index*DT;T=T1-T0;
    Nt=round(T/dt); 
    e=ones(Nt,1);
    B1=spdiags([-e e], [-1,0], Nt, Nt);
    B2=spdiags([(1-theta)*e theta*e], [-1,0], Nt, Nt);
    t=T0:dt:T1;
    if time_window_index==1
        u0=u_t0();
    else
        load('u_end.mat');
        u0=u_end;
    end
    source=zeros(Nx,Nt+1);
    for n=1:Nt+1
         source(:,n)=g0(t(n));
    end 
    Ix=eye(Nx);
    U_ref=zeros(Nx,Nt+1);
    U_ref(:,1)=u0;
    It_Newton_ref=zeros(1,Nt+1);
    for n=1:Nt
        z0=U_ref(:,n);
        bk=z0-dt*(1-theta)*F(z0)+dt*theta*source(:,n+1)+dt*(1-theta)*source(:,n);
        for k_Newton=1:Newton_Num
            res=bk-(z0+dt*theta*F(z0));
            if norm(res,inf)<=Newton_Tol/1000
                break;
            else
                Jac=Ix+dt*theta*dF(z0);
                dz=Jac\res;
                z0=z0+dz;
            end
        end
        It_Newton_ref(n+1)=k_Newton;
        U_ref(:,n+1)=z0;
    end
    u_end=U_ref(:,end);

    mat_b=zeros(Nx,Nt);
    for n=1:Nt
        if n==1
            mat_b(:,n)=u0-dt*(1-theta)*F(u0)+dt*(theta*source(:,n+1)+(1-theta)*source(:,n));
        else
            mat_b(:,n)=dt*(theta*source(:,n+1)+(1-theta)*source(:,n));
        end
    end
    vec_b=reshape(mat_b,Nx*Nt,1);
    U0=zeros(Nx,Nt);
    k=1;
    Err=zeros(1,Newton_Num);
    Err(k)=max(max(abs(U_ref(:,2:Nt+1)-U0)));
    
    fprintf('Newton Iteration k=%d: error=%2.15f\n',k-1,Err(k));
   
    
    Ku=zeros(Nx*Nt,1);
    JAC=zeros(Nx*Nt,Nx*Nt);
    for n=1:Nt
        if n==1 
            Ku((n-1)*Nx+1:n*Nx)=U0(:,n)+dt*theta*F(U0(:,n));
        else 
            Ku((n-1)*Nx+1:n*Nx)=U0(:,n)+dt*theta*F(U0(:,n))-U0(:,n-1)+dt*(1-theta)*F(U0(:,n-1));
        end
    end
    res=vec_b-Ku;
     It_GMRES0=0;
    for k=1:Newton_Num 
        if flag_solverP==0
           [dU,FLAG,RELRES,ITER,RESVEC]=gmres(@(du)K_times_U(du,U0),res,100,Newton_Tol,120,...
           @(du)invP_times_U_V0(du,U0,B1,B2),[],zeros(Nt*Nx,1));
        elseif flag_solverP==2
           [dU,FLAG,RELRES,ITER,RESVEC]=gmres(@(du)K_times_U(du,U0),res,100,Newton_Tol,120,...
           @(du)invP_times_U_V2(du,U0,B1,B2),[],zeros(Nt*Nx,1));
        else
           [dU,FLAG,RELRES,ITER,RESVEC]=gmres(@(du)K_times_U(du,U0),res,100,Newton_Tol,120,...
           @(du)invP_times_U_V3(du,U0,B1,B2),[],zeros(Nt*Nx,1));
        end
        It_GMRES0=It_GMRES0+ITER(2);
        U0=reshape(dU,Nx,Nt)+U0;
        Ku=zeros(Nx*Nt,1);
        JAC=zeros(Nx*Nt,Nx*Nt);
        for n=1:Nt
            if n==1 
                Ku((n-1)*Nx+1:n*Nx)=U0(:,n)+dt*theta*F(U0(:,n));
            else 
                Ku((n-1)*Nx+1:n*Nx)=U0(:,n)+dt*theta*F(U0(:,n))-U0(:,n-1)+dt*(1-theta)*F(U0(:,n-1));
            end
        end
        res=vec_b-Ku;
        Err(k)=max(max(abs(U_ref(:,2:Nt+1)-U0))); 
        fprintf('Newton Iteration k=%d: error=%2.15f, It_GMRES=%d\n',k,Err(k),ITER(2));
        if Err(k)<=Newton_Tol
            break;
        end
    end 
    Totoal_GMRES(solverP)=It_GMRES0;
end

fprintf('Total GMRES Iterations for Method-1: %d\n', Totoal_GMRES(1));
fprintf('Total GMRES Iterations for Method-2: %d\n', Totoal_GMRES(2));
fprintf('Total GMRES Iterations for Method-3: %d\n', Totoal_GMRES(3));



