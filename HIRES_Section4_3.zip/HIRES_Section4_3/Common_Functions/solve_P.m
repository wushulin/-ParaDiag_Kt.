function val=solve_P(du,B1,B2,b,barN)
global dt Nt Nx
val=zeros(Nx*Nt,1);
Ix=eye(Nx);
b1_1=B1(1,1);b1_2=B1(2,1);
b2_1=B2(1,1);b2_2=B2(2,1);
X=zeros(Nx*Nt,1);
for n=1:Nt
    if n==1
        X((n-1)*Nx+1:n*Nx)=(b1_1*Ix+dt*b2_1*b(n)*barN)\du((n-1)*Nx+1:n*Nx);
    else
        bn=du((n-1)*Nx+1:n*Nx)-(b1_2*Ix+dt*b2_2*b(n-1)*barN)*X((n-2)*Nx+1:(n-1)*Nx);
        X((n-1)*Nx+1:n*Nx)=(b1_1*Ix+dt*b2_1*b(n)*barN)\bn;
    end
end
val=X;
end
