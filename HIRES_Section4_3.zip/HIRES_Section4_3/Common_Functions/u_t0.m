function u_init = u_t0()
u_init=[1;zeros(6,1);0.0057];
end