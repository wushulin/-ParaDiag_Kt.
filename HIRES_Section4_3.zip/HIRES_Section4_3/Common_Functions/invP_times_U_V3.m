function val=invP_times_U_V3(du,U0,B1,B2)  
global Nt
Nx=length(U0(:,1));
A1 = dF(U0(:, 1));
[m, ~] = size(A1);
vecs = zeros(m^2, Nt);
for n = 1:Nt
    An = dF(U0(:, n));    
    vecs(:, n) = An(:);   
end
 
G = vecs' * vecs;
[V, eigvals] = eigs(G, 1,'la');
u = V(:, 1);  lambda = eigvals(1);  
u = u / norm(u);
barN = zeros(m, m);
for n = 1:Nt
    barN = barN + u(n) * dF(U0(:, n));
end
b = u;


if sum(b < 0) > Nt/2
    b = -b;
    barN = -barN;
end

val=solve_P(du,B1,B2,b,barN);
end