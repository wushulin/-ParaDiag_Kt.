function val=invP_times_U_V3(du,U0,B1,B2)  % SVD: barN and b simultaneous
global Nt
Nx=length(U0(:,1));
% snapshort_matrix=zeros(Nx^2,Nt);
% for n=1:Nt
%     snapshort_matrix(:,n)=reshape(dF(U0(:,n)),Nx^2,1);
% end
% [U,S,V]=svd(snapshort_matrix);
% b=S(1,1)*V(:,1);
% barN=reshape(U(:,1),Nx,Nx);
%val=(kron(B1,Ix)+dt*kron(B2*diag(b),barN))\du;

A1 = dF(U0(:, 1));
[m, ~] = size(A1);
vecs = zeros(m^2, Nt);
for n = 1:Nt
    An = dF(U0(:, n));   % ��ȡ��n�������
    vecs(:, n) = An(:);  % ������
end

% ����Gram����
G = vecs' * vecs;
[V, eigvals] = eigs(G, 1,'la');
u = V(:, 1);  lambda = eigvals(1);  
u = u / norm(u);
barN = zeros(m, m);
for n = 1:Nt
    barN = barN + u(n) * dF(U0(:, n));
end
b = u;


if sum(b < 0) > Nt/2
    b = -b;
    barN = -barN;
end

val=solve_P(du,B1,B2,b,barN);
end