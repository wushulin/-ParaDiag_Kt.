function val=invP_times_U_V0(du,U0,B1,B2) % Average by Gander
global Nt alp Nx
It=speye(Nt);
Ix=speye(Nx);
barN=zeros(Nx,Nx);
for n=1:Nt
    barN=barN+dF(U0(:,n))/Nt;
end
%val=(kron(B1,Ix)+dt*kron(B2,barN))\du;
b=ones(Nt,1);
val=solve_P(du,B1,B2,b,barN);
end
