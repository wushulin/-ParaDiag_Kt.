function gt = g0(t) 
    gt = zeros(8,1);
    gt(1) = 0.0007; 
end