
function val=invP_times_U_V1(du,U0,B1,B2) % Heuristic by Lin (first b and then barN)
global Nt alp Nx
It=speye(Nt);
Ix=speye(Nx);
b=zeros(1,Nt);
barN=zeros(Nx,Nx);
for n=1:Nt
    b(n)=norm(dF(U0(:,n)),2);
end
for n=1:Nt
    barN=barN+dF(U0(:,n))*(b(n)/sum(b));
end
%val=(kron(B1,Ix)+dt*kron(B2*diag(b),barN))\du; 
val=solve_P(du,B1,B2,b,barN);
end