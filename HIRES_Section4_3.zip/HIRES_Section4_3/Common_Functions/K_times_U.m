function val=K_times_U(du,U0)
global Nt Nx theta dt
dU=reshape(du,Nx,Nt); 
Z=zeros(Nx,Nt);
nonlinear_term=zeros(Nx,Nt);
for n=1:Nt
    nonlinear_term(:,n)=dF(U0(:,n))*dU(:,n);
end
for n=1:Nt
    if n==1     
        Z(:,n)=dU(:,n)+dt*theta*nonlinear_term(:,n);
    else
        Z(:,n)=dU(:,n)+dt*theta*nonlinear_term(:,n)-dU(:,n-1)+dt*(1-theta)*nonlinear_term(:,n-1);
    end
end
val=reshape(Z,Nx*Nt,1);
end
