function val=invP_times_U_V2(du,U0,B1,B2)  % Heuristic by Wu (first barN and then b)
global Nt alp Nx
It=speye(Nt);
Ix=speye(Nx);
b=zeros(1,Nt);
barN=zeros(Nx,Nx);
for n=1:Nt
    barN=barN+dF(U0(:,n))/Nt;
end
denominator=trace(transpose(barN)*barN);
for n=1:Nt
    b(n)=trace(transpose(dF(U0(:,n)))*barN)/denominator;
end
%val=(kron(B1,Ix)+dt*kron(B2*diag(b),barN))\du; 
val=solve_P(du,B1,B2,b,barN);
end
