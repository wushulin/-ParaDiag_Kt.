clear; clc;  
current_path = fileparts(mfilename('fullpath'));
addpath(fullfile(current_path, 'Common_Functions'));
ProblemData;
global M Kt  Nt Nx dt theta alpha
alpha=0.001;
 
theta = 1/2;       % theta=0.5: midpoint, theta=1: implicit Euler
dt = 0.3;        
T_end =12;       
Nt = ceil(T_end / dt);   
e=ones(Nt,1);
B1=spdiags([-e e], [-1,0], Nt, Nt);
B2=spdiags([(1-theta)*e theta*e], [-1,0], Nt, Nt);
C1=B1;
C1(1,Nt)=alpha*C1(2,1);
C2=B2;
C2(1,Nt)=alpha*C2(2,1);
time = 0:dt:T_end;  % 时间网格
It=speye(Nt);
 
fprintf('Generate FEM mesh...\n');
[p, e, t] = generate_mesh_with_boundary_curve(0.25);
Nx = size(p, 2);   
 

 
fprintf('Assemble mass matrix M and stiff matrix K_n...\n');
M = assemble_mass_matrix(p, t);
 Kt=zeros(Nx,Nx,Nt);
 for n=1:Nt
     Kt(:,:,n)= assemble_stiffness_matrix(p, t, time(n)+dt*theta);
 end 
It=speye(Nt);Ix=speye(Nx);
calK=sparse(Nt*Nx,Nt*Nx);
for n=1:Nt 
     calK((n-1)*Nx+1:n*Nx,(n-1)*Nx+1:n*Nx)=Kt(:,:,n);
end
calA=kron(B1,M)+dt*calK*kron(B2,Ix);
[barK0,b0]=getKb(0);
 calP0=kron(C1,M)+dt*kron(diag(b0)*C2,barK0);
[barK2,b2]=getKb(2);
 calP2=kron(C1,M)+dt*kron(diag(b2)*C2,barK2);
[barK3,b3]=getKb(3);
 calP3=kron(C1,M)+dt*kron(diag(b3)*C2,barK3);
fprintf('Compute eigenvalues for preconditioned matrix for Method-1...\n');
eig_invP0A=eig(full(calP0\calA));
fprintf('Compute eigenvalues for preconditioned matrix for Method-2...\n');
eig_invP2A=eig(full(calP2\calA));
fprintf('Compute eigenvalues for preconditioned matrix for Method-3...\n');
eig_invP3A=eig(full(calP3\calA));

figure(1);
plot(real(eig_invP0A),imag(eig_invP0A),'ko');
set(gca,'FontSize',15);
xlabel('Re$(\mathcal{P}_{\alpha}^{-1}\mathcal{A})$','FontSize',21,'Interpreter','latex');
ylabel('Im$(\mathcal{P}_{\alpha}^{-1}\mathcal{A})$','FontSize',21,'Interpreter','latex');
title('Method-1','FontSize',21);

figure(2);
plot(real(eig_invP2A),imag(eig_invP2A),'r*');
set(gca,'FontSize',15);
xlabel('Re$(\mathcal{P}_{\alpha}^{-1}\mathcal{A})$','FontSize',21,'Interpreter','latex');
ylabel('Im$(\mathcal{P}_{\alpha}^{-1}\mathcal{A})$','FontSize',21,'Interpreter','latex');
title('Method-2','FontSize',21);
figure(3);
plot(real(eig_invP3A),imag(eig_invP3A),'bs');
set(gca,'FontSize',15);
xlabel('Re$(\mathcal{P}_{\alpha}^{-1}\mathcal{A})$','FontSize',21,'Interpreter','latex');
ylabel('Im$(\mathcal{P}_{\alpha}^{-1}\mathcal{A})$','FontSize',21,'Interpreter','latex');
title('Method-3','FontSize',21);

figure(4);
plot(1:Nx*Nt,sort(abs(eig_invP0A)),'k-.o',1:Nx*Nt,sort(abs(eig_invP2A)),'r-.*',1:Nx*Nt,sort(abs(eig_invP3A)),'b-.s')

