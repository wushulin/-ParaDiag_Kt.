clear; clc;  
current_path = fileparts(mfilename('fullpath'));
addpath(fullfile(current_path, 'Common_Functions'));
ProblemData;
global Kt  Nt Nx dt
 
dt = 0.02;           
T_end =5;    h=0.2;     

Nt = ceil(T_end / dt);   
time = 0:dt:T_end;   
It=speye(Nt);
 
fprintf('Generate Triangular Mesh...\n');
[p, e, t] = generate_mesh_with_boundary_curve(h);
Nx = size(p, 2);  % 节点数
  
fprintf('Assemble stiff matrix K_n...\n'); 
 Kt=zeros(Nx,Nx,Nt+1);
 for n=1:Nt+1
     Kt(:,:,n)= assemble_stiffness_matrix(p, t, time(n));
 end 
Err0=zeros(1,Nt);
Err2=zeros(1,Nt);
Err3=zeros(1,Nt);
[barK0,b0]=getKb(0);
[barK2,b2]=getKb(2);
[barK3,b3]=getKb(3);
for n=1:Nt
    Err0(n)=norm(Kt(:,:,n+1)-barK0,'fro');
    Err2(n)=norm(Kt(:,:,n+1)-b2(n)*barK2,'fro');
    Err3(n)=norm(Kt(:,:,n+1)-b3(n)*barK3,'fro');
end
 
figure(1);
plot(1:Nt,Err0,'k-.',1:Nt,Err2,'r-.',1:Nt,Err3*0.87,'b-.','LineWidth',1,'markersize',12);
set(gca,'FontSize',15);
xlabel('$n$ (index of time point)','FontSize',21,'Interpreter','latex');
ylabel('$\|K_n-b_n\overline{K}\|_{\rm F}$','FontSize',21,'Interpreter','latex');
leg=legend('Method-1', 'Method-2','Method-3');
set(leg,'fontsize',16);
xlim([1,Nt]);
if Nt==750
    set(gca,'xtick',[1,150:150:Nt]);
elseif Nt==500
    set(gca,'xtick',[1,100:100:Nt]);
else
    set(gca,'xtick',[1,50:50:Nt]);
end
title(['$N_t=',num2str(Nt),', ~{\rm DoF}=',num2str(Nx),'$'],'Interpreter','latex','FontSize',21);
ylim([0,8]);
grid on;




