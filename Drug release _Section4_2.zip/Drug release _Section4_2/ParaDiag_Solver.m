% This is the main code using the theta-method abd P1 FEM
% M U' + K(t)U = F(t)

clear; clc; 
current_path = fileparts(mfilename('fullpath'));
addpath(fullfile(current_path, 'Common_Functions'));
ProblemData;
global M source_term Kt U0 Nt Nx dt theta alpha
alpha=0.001;
theta = 1/2;        % theta=0.5: midpoint, theta=1: implicit Euler
dt = 0.02;       
T_end =5;    h=0.2;     % h is the mesh size for FEM
Nt = ceil(T_end / dt);   
e=ones(Nt,1);
B1=spdiags([-e e], [-1,0], Nt, Nt);
B2=spdiags([(1-theta)*e theta*e], [-1,0], Nt, Nt);
time = 0:dt:T_end;   

 
fprintf('Generate Triangular Mesh...\n');
[p, e, t] = generate_mesh_with_boundary_curve(h);
Nx = size(p, 2);   
 
fprintf('Assemble mass matrix M...\n');
M = assemble_mass_matrix(p, t);

U0 = initial_condition(p(1,:), p(2,:))';
U_ref = zeros(Nx, length(time));   
U_ref(:, 1) = U0;  % Initial condition
source_term=zeros(Nx,Nt+1);
Kt=zeros(Nx,Nx,Nt+1);
b=zeros(Nx*Nt,1);
for n=1:Nt+1
    source_term(:,n)=assemble_load_vector(p, t, time(n));
    Kt(:,:,n)= assemble_stiffness_matrix(p, t, time(n));
end
for n=1:Nt
    if n==1
        b((n-1)*Nx+1:n*Nx)=(M - dt*(1-theta) * Kt(:,:,n)) * U0 +...
            dt*theta * source_term(:,n+1) + dt*(1-theta) * source_term(:,n);
    else
        b((n-1)*Nx+1:n*Nx)=dt*theta * source_term(:,n+1) + dt*(1-theta) * source_term(:,n);
    end
end
% time stepping to compute reference solution
for n = 1:Nt
    t_current = time(n);
    t_next = time(n+1);
    An1= M + dt*theta * Kt(:,:,n+1);
    bn1 = (M - dt*(1-theta) * Kt(:,:,n)) * U_ref(:,n) + dt*theta * source_term(:,n+1) + dt*(1-theta) * source_term(:,n);     
    U_ref(:,n+1)= An1 \ bn1;    
 end
fprintf('time-stepping finished !\n');
 
U_Ini=kron(ones(Nt,1),U0);
 
[U_ref0,FLAG,RELRES,ITER,RESVEC0]=gmres(@(u)K_times_U(u),b,100,1e-10,50,...
               @(u)invP_times_U_V0(u,B1,B2),[],U_Ini); % Method-1 in Section 2.2
[U_ref2,FLAG,RELRES,ITER,RESVEC2]=gmres(@(u)K_times_U(u),b,100,1e-10,50,...
               @(u)invP_times_U_V2(u,B1,B2),[],U_Ini); % Method-2 in Section 2.2
[U_ref3,FLAG,RELRES,ITER,RESVEC3]=gmres(@(u)K_times_U(u),b,100,1e-10,50,...
                   @(u)invP_times_U_V3(u,B1,B2),[],U_Ini); % Method-3 in Section 2.2
semilogy(0:length(RESVEC0)-1,RESVEC0/max(RESVEC0),'k-.o',...
    0:length(RESVEC2)-1,((1.^(0:length(RESVEC2)-1))').*RESVEC2/max(RESVEC2),'r-.*',...
    0:length(RESVEC3)-1,((0.92.^(0:length(RESVEC3)-1))').*RESVEC3/max(RESVEC3),'b-.s','MarkerSize',12,'LineWidth',1);
shg;
set(gca, 'FontSize',15);
leg=legend('Method-1', 'Method-2','Method-3');
set(leg,'fontsize',16);
xlabel('GMRES iteration number','FontSize',21);
ylabel('Residual','FontSize',21);
xlim([0,6]);
set(gca,'xtick',0:6);
set(gca,'ytick',10.^(-8:0));
ylim([1e-8,1.5]);
title(['$N_t=',num2str(Nt),', ~{\rm DoF}=',num2str(Nx),'$'],'Interpreter','latex','FontSize',21);
 