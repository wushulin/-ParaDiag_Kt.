function g =F(x, y, t)
    global Problem_Parameter
    idx.kappa0 = 11; idx.gamma = 12; idx.tau = 13; idx.R0 = 14; idx.delta = 15;
    idx.S0 = 16; idx.sigma = 17; idx.t_s = 18; idx.t_d = 19;
    
    r = sqrt(x.^2 + y.^2);
    h_x = 0.5 * (1 + tanh((r - Problem_Parameter(idx.R0))/Problem_Parameter(idx.delta)));
    kappa = Problem_Parameter(idx.kappa0) * (1 + Problem_Parameter(idx.gamma) * ...
            (1 - exp(-t/Problem_Parameter(idx.tau))) .* h_x);
    
    x0 = 0.5; y0 = 0.3;
    %source_dist = sqrt((x-x0).^2 + (y-y0).^2);
    source_dist = sqrt((x-x0*sin(3*pi*t)).^2 + (y-y0*cos(4*pi*t^2)).^2);
    S = Problem_Parameter(idx.S0) * exp(-source_dist.^2/(2*Problem_Parameter(idx.sigma)^2));
    
    if t>= Problem_Parameter(idx.t_d)
        %time_mod = t / (t + Problem_Parameter(idx.t_s));
        time_mod = sin(2*pi*t) / (cos(sqrt(5)*pi*t)^2 + Problem_Parameter(idx.t_s));
    else
        time_mod = 0;
    end 
    g = -kappa + S * time_mod;
end