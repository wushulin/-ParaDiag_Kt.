function val=K_times_U(u)
global Nt  Nx  M Kt dt theta U0
val0=zeros(Nx,Nt);
mat_u=[U0,reshape(u,Nx,Nt)];
for n=1:Nt
    if n==1
        val0(:,n)=(M + dt*theta * Kt(:,:,n+1))*mat_u(:,n+1);
    else
        val0(:,n)=(M + dt*theta * Kt(:,:,n+1))*mat_u(:,n+1)-(M - dt*(1-theta) * Kt(:,:,n)) * mat_u(:,n);  
    end
end
val=reshape(val0,Nx*Nt,1);
end