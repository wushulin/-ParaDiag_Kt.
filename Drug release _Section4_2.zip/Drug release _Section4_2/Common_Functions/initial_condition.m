function u0 = initial_condition(x, y)
    global Problem_Parameter
    idx.u_max = 20; idx.R_load = 21;
    
    r = sqrt(x.^2 + y.^2);
    u0 = Problem_Parameter(idx.u_max) * exp(-r.^2/(2*Problem_Parameter(idx.R_load)^2));
end