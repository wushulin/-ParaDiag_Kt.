function val=invP_times_U_V0(du,B1,B2) % Average by Gander
global Nt alp Nx Kt
barN=zeros(Nx,Nx);
for n=1:Nt
    barN=barN+Kt(:,:,n+1)/Nt;
end
%val=(kron(B1,Ix)+dt*kron(B2,barN))\du;
b=ones(Nt,1);
val=solve_P(du,B1,B2,b,barN);
end