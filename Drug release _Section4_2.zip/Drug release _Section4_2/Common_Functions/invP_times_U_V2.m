function val=invP_times_U_V2(du,B1,B2)  % Heuristic by Wu (first barN and then b)
global Nt alp Nx Kt
b=zeros(1,Nt);
barN=zeros(Nx,Nx);
for n=1:Nt
    barN=barN+Kt(:,:,n+1)/Nt;
end
denominator=trace(transpose(barN)*barN);
for n=1:Nt
    b(n)=trace(transpose(Kt(:,:,n+1))*barN)/denominator;
end
%val=(kron(B1,Ix)+dt*kron(B2*diag(b),barN))\du; 
val=solve_P(du,B1,B2,b,barN);
end
