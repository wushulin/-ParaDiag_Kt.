function [x_boundary, y_boundary] = boundary_curve()
    global Problem_Parameter
    idx.a = 1; idx.b = 2; idx.epsilon = 3;
    
    theta_boundary = linspace(0, 2*pi, 100);
    r_boundary = 1 - Problem_Parameter(idx.epsilon)*cos(3*theta_boundary);
    x_boundary = Problem_Parameter(idx.a) * r_boundary .* cos(theta_boundary);
    y_boundary = Problem_Parameter(idx.b) * r_boundary .* sin(theta_boundary);
end