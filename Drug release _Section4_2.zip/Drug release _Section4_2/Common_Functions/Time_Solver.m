function Time_Solver()
% 主程序：用线性theta方法求解P1有限元离散的ODE系统
% M U' + K(t)U = F(t)

clear; clc; close all;

% 设置全局参数数组
global Problem_Parameter


% 时间离散参数
theta = 0.5;        % theta方法参数 (0.5=Crank-Nicolson, 1=向后欧拉)
dt = 0.02;          % 时间步长
T_end =115;        % 结束时间
t_steps = ceil(T_end / dt);  % 时间步数
time = 0:dt:T_end;  % 时间网格

fprintf('开始时间求解...\n');
fprintf('参数: theta=%.1f, dt=%.3f, T_end=%.1f, 步数=%d\n', theta, dt, T_end, t_steps);

% 生成三角形网格
fprintf('生成三角形网格...\n');
[p, e, t] = generate_mesh_with_boundary_curve(0.1);
n_nodes = size(p, 2);  % 节点数

% 确保t矩阵有4行
if size(t, 1) < 4
    t(4, :) = 1; % 添加子域标签行
end

% 组装质量矩阵M (与时间无关)
fprintf('组装质量矩阵M...\n');
M = assemble_mass_matrix(p, t);

% 计算初始条件
fprintf('计算初始条件...\n');
U0 = initial_condition(p(1,:), p(2,:))';
%U = zeros(n_nodes, length(time));  % 存储所有时间步的解
U(:, 1) = U0;  % 初始条件
Un=U0;
% 创建图形窗口用于实时显示
figure('Position', [100, 100, 800, 600]);

% 时间步进求解
fprintf('开始时间步进求解...\n');
for n = 1:t_steps
    t_current = time(n);
    t_next = time(n+1);
    
    % 显示进度
    if mod(n, 25) == 0
        fprintf('  时间步 %d/%d, t=%.2f\n', n, t_steps, t_current);
    end
    
    % 计算当前时间步的矩阵
    K_current = assemble_stiffness_matrix(p, t, t_current);
    F_current = assemble_load_vector(p, t, t_current);
    
    % 计算下一时间步的矩阵
    K_next = assemble_stiffness_matrix(p, t, t_next);
    F_next = assemble_load_vector(p, t, t_next);
    
    % 线性theta方法离散
    % M*(U^{n+1} - U^n)/dt + theta*K_next*U^{n+1} + (1-theta)*K_current*U^n = theta*F_next + (1-theta)*F_current
    
    % 重新整理为: A*U^{n+1} = b
    A = M/dt + theta * K_next;
    b = (M/dt - (1-theta) * K_current) * Un + theta * F_next + (1-theta) * F_current;
    
    % 求解线性系统
    Un = A \ b;
    
    % 实时绘制当前时间步的解
    clf; % 清除当前图形
    try
        pdeplot(p, [], t(1:3, :), 'XYData', Un, 'ColorMap', 'jet', 'Mesh', 'on');
        title(sprintf('药物浓度分布 (t = %.2f 小时)', t_next));
        xlabel('x (cm)');
        ylabel('y (cm)');
        colorbar;
        axis equal;
        caxis([0, max(U0)]); % 固定颜色轴范围便于观察变化
    catch
        % 如果pdeplot失败，使用替代方法
        trisurf(t(1:3, :)', p(1,:), p(2,:), zeros(size(p(1,:))), Un, ...
               'EdgeColor', 'k', 'FaceColor', 'interp');
        title(sprintf('药物浓度分布 (t = %.2f 小时)', t_next));
        xlabel('x (cm)');
        ylabel('y (cm)');
        colorbar;
        axis equal;
        view(2);
    end
    
    % 暂停0.3秒，形成动画效果
    pause(0.01);
    
    % 强制刷新图形
    drawnow;
end

fprintf('时间求解完成！\n');

% 保存结果
save('time_solution.mat', 'p', 't', 'time', 'U', 'theta', 'dt');

fprintf('程序执行完毕！\n');

end