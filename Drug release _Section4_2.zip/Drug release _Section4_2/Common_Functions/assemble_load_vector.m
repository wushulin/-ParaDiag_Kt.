function source_term = assemble_load_vector(p, t, current_time)
% 组装载荷向量F(t)
% 输入: p - 节点坐标矩阵, t - 单元连接矩阵, current_time - 当前时间t
% 输出: F - 载荷向量

global Problem_Parameter

n_nodes = size(p, 2);  % 节点数
n_elements = size(t, 2);  % 单元数

% 初始化载荷向量
source_term = zeros(n_nodes, 1);

% 遍历所有单元
for el = 1:n_elements
    % 获取当前单元的节点索引
    nodes = t(1:3, el);
    
    % 获取节点坐标
    x1 = p(1, nodes(1)); y1 = p(2, nodes(1));
    x2 = p(1, nodes(2)); y2 = p(2, nodes(2));
    x3 = p(1, nodes(3)); y3 = p(2, nodes(3));
    
    % 计算单元面积
    area = 0.5 * abs((x2-x1)*(y3-y1) - (x3-x1)*(y2-y1));
    
    % 计算单元中心点的源项
    x_center = (x1 + x2 + x3) / 3;
    y_center = (y1 + y2 + y3) / 3;
    
    % 计算源项g0(x,t)
    g0_val = F(x_center, y_center, current_time);
    
    % 线性元的载荷向量(3×1)
    % 使用集中质量近似: ∫g0φ_idΩ ≈ g0·area/3
    F_e = g0_val * area/3 * [1; 1; 1];
    
    % 组装到全局载荷向量
    source_term(nodes) = source_term(nodes) + F_e;
end
end