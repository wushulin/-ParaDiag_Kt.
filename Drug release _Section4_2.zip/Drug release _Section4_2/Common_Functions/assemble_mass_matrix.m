function M = assemble_mass_matrix(p, t)
n_nodes = size(p, 2);   
n_elements = size(t, 2);   
M = sparse(n_nodes, n_nodes);
for el = 1:n_elements
    nodes = t(1:3, el);
    x1 = p(1, nodes(1)); y1 = p(2, nodes(1));
    x2 = p(1, nodes(2)); y2 = p(2, nodes(2));
    x3 = p(1, nodes(3)); y3 = p(2, nodes(3));
    area = 0.5 * abs((x2-x1)*(y3-y1) - (x3-x1)*(y2-y1));
    M_e = area/12 * [2, 1, 1;
                     1, 2, 1;
                     1, 1, 2];
    M(nodes, nodes) = M(nodes, nodes) + M_e;
end
end