function M = assemble_mass_matrix(p, t)
% 组装质量矩阵M
% 输入: p - 节点坐标矩阵, t - 单元连接矩阵
% 输出: M - 质量矩阵(稀疏矩阵)

n_nodes = size(p, 2);  % 节点数
n_elements = size(t, 2);  % 单元数

% 初始化质量矩阵
M = sparse(n_nodes, n_nodes);

% 遍历所有单元
for el = 1:n_elements
    % 获取当前单元的节点索引
    nodes = t(1:3, el);
    
    % 获取节点坐标
    x1 = p(1, nodes(1)); y1 = p(2, nodes(1));
    x2 = p(1, nodes(2)); y2 = p(2, nodes(2));
    x3 = p(1, nodes(3)); y3 = p(2, nodes(3));
    
    % 计算单元面积
    area = 0.5 * abs((x2-x1)*(y3-y1) - (x3-x1)*(y2-y1));
    
    % 线性元的一致质量矩阵(3×3)
    M_e = area/12 * [2, 1, 1;
                     1, 2, 1;
                     1, 1, 2];
    
    % 组装到全局质量矩阵
    M(nodes, nodes) = M(nodes, nodes) + M_e;
end
end