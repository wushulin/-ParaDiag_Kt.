function c = diffusion_coefficient(X, Y, t, dist)
    global Problem_Parameter
    idx.c0 = 4; idx.alpha = 5; idx.lambda = 6; idx.beta = 7;
    idx.Lx = 8; idx.Ly = 9; idx.k = 10;
    
    % 时间调制函数
    f_t = 1 - exp(-Problem_Parameter(idx.k)*t);
    
    % 空间调制函数
    spatial_mod = 1 + Problem_Parameter(idx.beta) * ...
                  sin(pi*X/Problem_Parameter(idx.Lx)) .* ...
                  cos(pi*Y/Problem_Parameter(idx.Ly)) * f_t;
    
    % 边界衰减项
    boundary_decay = 1 + Problem_Parameter(idx.alpha)*t .* ...
                     exp(-Problem_Parameter(idx.lambda)*abs(dist));
    
    c = Problem_Parameter(idx.c0) * boundary_decay .* spatial_mod;
end