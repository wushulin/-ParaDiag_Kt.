function val=invP_times_U_V3(du,B1,B2)  % optimize barN and b simultaneous
global Nt Kt 

A1 = Kt(:,:,2);
[m, ~] = size(A1);
vecs = zeros(m^2, Nt);
for n = 1:Nt
    An = Kt(:,:,n+1);    
    vecs(:, n) = An(:);  
end
 
G = vecs' * vecs;
[V, eigvals] = eigs(G, 1,'la');
u = V(:, 1);  lambda = eigvals(1);  
u = u / norm(u);
barN = zeros(m, m);
for n = 1:Nt
    barN = barN + u(n) * Kt(:,:,n+1);
end
b = u;


if sum(b < 0) > Nt/2
    b = -b;
    barN = -barN;
end

val=solve_P(du,B1,B2,b,barN);
end