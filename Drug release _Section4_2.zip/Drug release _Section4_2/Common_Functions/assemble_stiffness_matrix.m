function K = assemble_stiffness_matrix(p, t, current_time)
% 组装刚度矩阵K(t)
% 输入: p - 节点坐标矩阵, t - 单元连接矩阵, current_time - 当前时间t
% 输出: K - 刚度矩阵(稀疏矩阵)

global Problem_Parameter

n_nodes = size(p, 2);  % 节点数
n_elements = size(t, 2);  % 单元数

% 初始化刚度矩阵
K = sparse(n_nodes, n_nodes);

% 遍历所有单元
for el = 1:n_elements
    % 获取当前单元的节点索引
    nodes = t(1:3, el);
    
    % 获取节点坐标
    x1 = p(1, nodes(1)); y1 = p(2, nodes(1));
    x2 = p(1, nodes(2)); y2 = p(2, nodes(2));
    x3 = p(1, nodes(3)); y3 = p(2, nodes(3));
    
    % 计算单元面积
    area = 0.5 * abs((x2-x1)*(y3-y1) - (x3-x1)*(y2-y1));
    
    % 计算单元形函数梯度(常数)
    b = [y2 - y3; y3 - y1; y1 - y2];
    c = [x3 - x2; x1 - x3; x2 - x1];
    
    % 形函数梯度矩阵
    grad_phi = [b, c] / (2 * area);
    
    % 计算单元中心点的扩散系数(近似处理)
    x_center = (x1 + x2 + x3) / 3;
    y_center = (y1 + y2 + y3) / 3;
    
    % 计算中心点的距离函数(用于扩散系数)
    theta_center = atan2(y_center, x_center);
    r_norm_center = sqrt((x_center/Problem_Parameter(1))^2 + ...
                         (y_center/Problem_Parameter(2))^2 + ...
                         Problem_Parameter(3)*cos(3*theta_center));
    dist_center = 1 - r_norm_center;
    
    % 计算扩散系数c(x,t)
    c_val = diffusion_coefficient(x_center, y_center, current_time, dist_center);
    
    % 计算单元刚度矩阵
    K_e = zeros(3, 3);
    for i = 1:3
        for j = 1:3
            % ∫(c∇φ_i·∇φ_j)dΩ ≈ c·area·(∇φ_i·∇φ_j)
            grad_dot = grad_phi(i,1)*grad_phi(j,1) + grad_phi(i,2)*grad_phi(j,2);
            K_e(i, j) = c_val * area * grad_dot;
        end
    end
    
    % 组装到全局刚度矩阵
    K(nodes, nodes) = K(nodes, nodes) + K_e;
end
end