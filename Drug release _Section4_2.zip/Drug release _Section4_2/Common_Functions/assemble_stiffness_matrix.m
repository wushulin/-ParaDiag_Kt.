function K = assemble_stiffness_matrix(p, t, current_time)
global Problem_Parameter
n_nodes = size(p, 2);  
n_elements = size(t, 2);   
 
K = sparse(n_nodes, n_nodes);

for el = 1:n_elements 
    nodes = t(1:3, el); 
    x1 = p(1, nodes(1)); y1 = p(2, nodes(1));
    x2 = p(1, nodes(2)); y2 = p(2, nodes(2));
    x3 = p(1, nodes(3)); y3 = p(2, nodes(3));
    area = 0.5 * abs((x2-x1)*(y3-y1) - (x3-x1)*(y2-y1));
    b = [y2 - y3; y3 - y1; y1 - y2];
    c = [x3 - x2; x1 - x3; x2 - x1];
    grad_phi = [b, c] / (2 * area);
    x_center = (x1 + x2 + x3) / 3;
    y_center = (y1 + y2 + y3) / 3;
    theta_center = atan2(y_center, x_center);
    r_norm_center = sqrt((x_center/Problem_Parameter(1))^2 + ...
                         (y_center/Problem_Parameter(2))^2 + ...
                         Problem_Parameter(3)*cos(3*theta_center));
    dist_center = 1 - r_norm_center;
    c_val = diffusion_coefficient(x_center, y_center, current_time, dist_center);
    K_e = zeros(3, 3);
    for i = 1:3
        for j = 1:3
            grad_dot = grad_phi(i,1)*grad_phi(j,1) + grad_phi(i,2)*grad_phi(j,2);
            K_e(i, j) = c_val * area * grad_dot;
        end
    end
    K(nodes, nodes) = K(nodes, nodes) + K_e;
end
end