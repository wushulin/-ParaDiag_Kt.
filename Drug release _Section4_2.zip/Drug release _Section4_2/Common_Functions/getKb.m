function [barK,b]=getKb(solver_P)
global Nt Nx Kt
if solver_P==0
    barK=zeros(Nx,Nx);
    for n=1:Nt
        barK=barK+Kt(:,:,n)/Nt;
    end 
    b=ones(Nt,1);
elseif solver_P==2
     barK=zeros(Nx,Nx);
    for n=1:Nt
        barK=barK+Kt(:,:,n)/Nt;
    end
    denominator=trace(transpose(barK)*barK);
    for n=1:Nt
        b(n)=trace(transpose(Kt(:,:,n))*barK)/denominator;
    end
else
    A1 = Kt(:,:,2);
    [m, ~] = size(A1);
    vecs = zeros(m^2, Nt);
    for n = 1:Nt
        An = Kt(:,:,n);   % get the n-th block
        vecs(:, n) = An(:);  % vectorization
    end
    % compute Gram matrix
    G = vecs' * vecs;
    [V, eigvals] = eigs(G, 1,'la');
    u = V(:, 1);  lambda = eigvals(1);  
    u = u / norm(u);
    barK = sparse(m, m);
    for n = 1:Nt
        barK = barK + u(n) * Kt(:,:,n);
    end
    b = u;
    if sum(b < 0) > Nt/2
        b = -b;
        barK = -barK;
    end
end
end