function [x_points, y_points] = boundary_curve_points(theta0)
    global Problem_Parameter
    idx.a = 1; idx.b = 2; idx.epsilon = 3;
    
    r = 1 - Problem_Parameter(idx.epsilon)*cos(3*theta0);
    x_points = Problem_Parameter(idx.a) * r .* cos(theta0);
    y_points = Problem_Parameter(idx.b) * r .* sin(theta0);
end