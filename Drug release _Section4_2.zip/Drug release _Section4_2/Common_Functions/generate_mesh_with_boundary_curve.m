function [p, e, t] = generate_mesh_with_boundary_curve(h)

    theta0 = linspace(0, 2*pi, 100);
    theta0 = theta0(1:end-1); 
    [x_boundary, y_boundary] = boundary_curve_points(theta0);

    n = length(x_boundary);
    gd = [2; n; x_boundary(:); y_boundary(:)];

    try
        dl = decsg(gd);
        
        model = createpde();
        
        geometryFromEdges(model, dl);
        
        generateMesh(model, 'Hmax', h, 'GeometricOrder', 'linear');

        mesh_data = model.Mesh;
        p = mesh_data.Nodes;
        e = mesh_data.Elements;
        t = mesh_data.Elements; 
        
    catch
        fprintf('PDE工具箱方法失败，使用Delaunay三角剖分\n');
        P = [x_boundary', y_boundary'];
        DT = delaunayTriangulation(P);
        p = DT.Points';
        t = DT.ConnectivityList';
        e = []; 

        if size(t, 1) < 4
            t(4, :) = 1; 
        end
    end
end