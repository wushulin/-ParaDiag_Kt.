function [p, e, t] = generate_mesh_with_boundary_curve(h)
    % 使用boundary_curve生成网格
    global Problem_Parameter
    
    % 生成边界点
    theta0 = linspace(0, 2*pi, 100);
    theta0 = theta0(1:end-1); % 移除重复的端点
    [x_boundary, y_boundary] = boundary_curve_points(theta0);
    
    % 创建几何描述矩阵
    n = length(x_boundary);
    gd = [2; n; x_boundary(:); y_boundary(:)];
    
    % 创建分解几何矩阵
    try
        dl = decsg(gd);
        
        % 创建PDE模型
        model = createpde();
        
        % 设置几何
        geometryFromEdges(model, dl);
        
        % 生成网格
        generateMesh(model, 'Hmax', h, 'GeometricOrder', 'linear');
        
        % 提取网格数据
        mesh_data = model.Mesh;
        p = mesh_data.Nodes;
        e = mesh_data.Elements;
        t = mesh_data.Elements; % 使用完整的元素矩阵
        
    catch
        % 如果PDE工具箱方法失败，使用Delaunay三角剖分
        fprintf('PDE工具箱方法失败，使用Delaunay三角剖分\n');
        P = [x_boundary', y_boundary'];
        DT = delaunayTriangulation(P);
        p = DT.Points';
        t = DT.ConnectivityList';
        e = []; % Delaunay方法不提供边界信息
        
        % 确保t矩阵有4行
        if size(t, 1) < 4
            t(4, :) = 1; % 添加子域标签行
        end
    end
end