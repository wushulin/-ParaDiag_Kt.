function A = get(h, r)
    % 计算网格点数 N (确保覆盖区间 [0,1])
    if r == 1
        N = max(round(1/h), 1);
    else
        N = max(ceil(log(1 + (r-1)/h) / log(r)), 1);
    end
    
    % 计算实际步长因子 h_act 以满足总长度=1
    if r == 1
        h_act = h;
    else
        h_act = (r - 1) / (r^N - 1);
    end
    
    % 生成网格点: x(1)=0, x(N+1)=1
    x = zeros(1, N+1);
    for i = 0:N
        x(i+1) = 1 - h_act * (r^(N-i) - 1) / (r - 1);
    end
    
    % 计算区间长度: dx(i) = x(i+1) - x(i)
    dx = diff(x);  % dx(1)=x1-x0, dx(2)=x2-x1, ..., dx(N)=xN-x_{N-1}
    
    % 计算界面中点坐标: x_half(i) = (x(i) + x(i+1)) / 2
    x_half = (x(1:end-1) + x(2:end)) / 2;
    
    % 初始化矩阵 M (N x N) 和常数向量 C (稍后在 getg 中计算)
    M = zeros(N, N);
    
    % 处理第一行 (i=0, 对应 x0)
    dx1 = dx(1);  % Δx_{1/2} = x1 - x0
    p_half = x_half(1)^2;  % p_{1/2} = (x_{1/2})^2
    coef = p_half / (dx1^2);
    M(1, 1) = -coef;  % u0 系数
    if N > 1
        M(1, 2) = coef;  % u1 系数
    end
    
    % 处理中间行 (i=1 到 N-2, 对应 x1 到 x_{N-2})
    for idx = 2:(N-1)  % MATLAB 行索引 (对应网格点 x_{idx-1})
        k = idx - 1;  % 网格点索引 (0-based: x_k)
        dx_minus = dx(k);     % Δx_{k-1/2} = x_k - x_{k-1}
        dx_plus = dx(k+1);     % Δx_{k+1/2} = x_{k+1} - x_k
        p_minus = x_half(k)^2; % p_{k-1/2} = (x_{k-1/2})^2
        p_plus = x_half(k+1)^2; % p_{k+1/2} = (x_{k+1/2})^2
        denom = dx_minus + dx_plus;
        coef_left = p_minus / (dx_minus * denom);
        coef_right = p_plus / (dx_plus * denom);
        coef_center = -(coef_left + coef_right);
        
        % 填充矩阵 M
        M(idx, idx-1) = coef_left;   % u_{k-1}
        M(idx, idx) = coef_center;   % u_k
        if idx < N
            M(idx, idx+1) = coef_right;  % u_{k+1}
        end
    end
    
    % 处理最后一行 (i=N-1, 对应 x_{N-1})
    if N >= 2
        k = N-1;  % 网格点索引 (x_{N-1})
        dx_minus = dx(k);     % Δx_{k-1/2} = x_k - x_{k-1}
        dx_plus = dx(k+1);     % Δx_{k+1/2} = x_{k+1} - x_k
        p_minus = x_half(k)^2; % p_{k-1/2} = (x_{k-1/2})^2
        p_plus = x_half(k+1)^2; % p_{k+1/2} = (x_{k+1/2})^2
        denom = dx_minus + dx_plus;
        coef_left = p_minus / (dx_minus * denom);
        coef_center = -(coef_left + (p_plus / (dx_plus * denom)));
        
        % 填充矩阵 M (最后一行)
        M(N, N-1) = coef_left;  % u_{N-2}
        M(N, N) = coef_center;  % u_{N-1}
    end
    
    % 返回 A = -M (根据 ODE 系统形式 U' + De(t)A U = g(t))
    A = -M;
end