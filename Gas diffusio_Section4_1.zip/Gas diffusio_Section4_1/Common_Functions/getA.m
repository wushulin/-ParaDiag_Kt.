function A = get(h, r)
    if r == 1
        N = max(round(1/h), 1);
    else
        N = max(ceil(log(1 + (r-1)/h) / log(r)), 1);
    end
    
    if r == 1
        h_act = h;
    else
        h_act = (r - 1) / (r^N - 1);
    end
    
    x = zeros(1, N+1);
    for i = 0:N
        x(i+1) = 1 - h_act * (r^(N-i) - 1) / (r - 1);
    end
    
    dx = diff(x);  % dx(1)=x1-x0, dx(2)=x2-x1, ..., dx(N)=xN-x_{N-1}

    x_half = (x(1:end-1) + x(2:end)) / 2;
    
    M = zeros(N, N);
    
    dx1 = dx(1);  % Δx_{1/2} = x1 - x0
    p_half = x_half(1)^2;  % p_{1/2} = (x_{1/2})^2
    coef = p_half / (dx1^2);
    M(1, 1) = -coef;  
    if N > 1
        M(1, 2) = coef;  
    end
     
    for idx = 2:(N-1)   
        k = idx - 1;  
        dx_minus = dx(k);     % Δx_{k-1/2} = x_k - x_{k-1}
        dx_plus = dx(k+1);     % Δx_{k+1/2} = x_{k+1} - x_k
        p_minus = x_half(k)^2; % p_{k-1/2} = (x_{k-1/2})^2
        p_plus = x_half(k+1)^2; % p_{k+1/2} = (x_{k+1/2})^2
        denom = dx_minus + dx_plus;
        coef_left = p_minus / (dx_minus * denom);
        coef_right = p_plus / (dx_plus * denom);
        coef_center = -(coef_left + coef_right);
        
        % form matrix M
        M(idx, idx-1) = coef_left;   % u_{k-1}
        M(idx, idx) = coef_center;   % u_k
        if idx < N
            M(idx, idx+1) = coef_right;  % u_{k+1}
        end
    end
     
    if N >= 2
        k = N-1;   
        dx_minus = dx(k);     % Δx_{k-1/2} = x_k - x_{k-1}
        dx_plus = dx(k+1);     % Δx_{k+1/2} = x_{k+1} - x_k
        p_minus = x_half(k)^2; % p_{k-1/2} = (x_{k-1/2})^2
        p_plus = x_half(k+1)^2; % p_{k+1/2} = (x_{k+1/2})^2
        denom = dx_minus + dx_plus;
        coef_left = p_minus / (dx_minus * denom);
        coef_center = -(coef_left + (p_plus / (dx_plus * denom)));
 
        M(N, N-1) = coef_left;  % u_{N-2}
        M(N, N) = coef_center;  % u_{N-1}
    end
    
    % return A = -M (according to the ODE formulation U' + De(t)A U = g(t))
    A = -M;
end