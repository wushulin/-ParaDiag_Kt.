function nout=minftynorm(A,N,m)

NA=zeros(N,N);
for ii=1:N
    for jj=1:N
        NA(ii,jj)=norm(full(A((ii-1)*m+1:ii*m,(jj-1)*m+1:jj*m)),2);
    end
end
nout=norm(NA,inf);

end