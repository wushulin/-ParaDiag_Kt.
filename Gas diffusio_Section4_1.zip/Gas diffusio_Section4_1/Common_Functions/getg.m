function g = getg(h, t, b, r) 
    if r == 1
        N = max(round(1/h), 1);
    else
        N = max(ceil(log(1 + (r-1)/h) / log(r)), 1);
    end
     
    if r == 1
        h_act = h;
    else
        h_act = (r - 1) / (r^N - 1);
    end
     
    x = zeros(1, N+1);
    for i = 0:N
        x(i+1) = 1 - h_act * (r^(N-i) - 1) / (r - 1);
    end
     
    dx = diff(x);
    x_half = (x(1:end-1) + x(2:end)) / 2;
    C = zeros(N, 1);
    if N >= 2
        k = N-1;   
        dx_minus = dx(k);     % Δx_{k-1/2}
        dx_plus = dx(k+1);     % Δx_{k+1/2}
        p_plus = x_half(k+1)^2; % p_{k+1/2}
        denom = dx_minus + dx_plus;
        coef_right = p_plus / (dx_plus * denom);
        C(N) = coef_right * b;   
    elseif N == 1 
        dx1 = dx(1);
        p_half = x_half(1)^2;
        coef = p_half / (dx1^2);
        C(1) = coef * b;   
    end
     
    de_val = De(t);   
    g = de_val * C;
end