function g = getg(h, t, b, r)
    % 计算网格点数 N (同 get 函数)
    if r == 1
        N = max(round(1/h), 1);
    else
        N = max(ceil(log(1 + (r-1)/h) / log(r)), 1);
    end
    
    % 计算实际步长因子 h_act
    if r == 1
        h_act = h;
    else
        h_act = (r - 1) / (r^N - 1);
    end
    
    % 生成网格点
    x = zeros(1, N+1);
    for i = 0:N
        x(i+1) = 1 - h_act * (r^(N-i) - 1) / (r - 1);
    end
    
    % 计算区间长度和界面中点
    dx = diff(x);
    x_half = (x(1:end-1) + x(2:end)) / 2;
    
    % 初始化常数向量 C (N x 1)
    C = zeros(N, 1);
    
    % 仅当 N >= 2 时，最后一行有常数项
    if N >= 2
        k = N-1;  % 网格点索引 (x_{N-1})
        dx_minus = dx(k);     % Δx_{k-1/2}
        dx_plus = dx(k+1);     % Δx_{k+1/2}
        p_plus = x_half(k+1)^2; % p_{k+1/2}
        denom = dx_minus + dx_plus;
        coef_right = p_plus / (dx_plus * denom);
        C(N) = coef_right * b;  % 常数项 = coef_right * b
    elseif N == 1
        % 单区间情况 (x0=0, x1=1)
        dx1 = dx(1);
        p_half = x_half(1)^2;
        coef = p_half / (dx1^2);
        C(1) = coef * b;  % 常数项 = coef * b
    end
    
    % 计算 g(t) = De(t) * C
    de_val = De(t);  % 调用给定的 De(t) 函数
    g = de_val * C;
end