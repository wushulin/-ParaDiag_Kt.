function x = generate_mesh(h, r)
    % generate gradded mesh with more points near x=1 (via y=1-x)
    y = [0];   
    current = 0;
    i = 0;
    
    while current < 1
        step = h / (r^i);
        next_pt = current + step;
        
        if next_pt > 1
            next_pt = 1;
        end
        
        if next_pt > current
            y(end+1) = next_pt;
        end
        
        current = next_pt;
        i = i + 1;
         
        if i > 10000
            warning('fail !');
            break;
        end
    end
    
    x = 1 - y;
     
    x = flip(x);
     
    if x(1) > 0
        x = [0, x];
    end
    if x(end) < 1
        x = [x, 1];
    end
     
    x = unique(x);
    x = sort(x);
end