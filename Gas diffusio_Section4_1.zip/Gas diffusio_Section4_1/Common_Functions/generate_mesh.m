function x = generate_mesh(h, r)
    % 生成在x=1附近加密的网格（使用y=1-x变换）
    y = [0];  % 从y=0开始
    current = 0;
    i = 0;
    
    while current < 1
        % 步长按几何级数递减（在y=0附近加密）
        step = h / (r^i);
        next_pt = current + step;
        
        if next_pt > 1
            next_pt = 1;
        end
        
        if next_pt > current
            y(end+1) = next_pt;
        end
        
        current = next_pt;
        i = i + 1;
        
        % 安全机制：防止无限循环
        if i > 10000
            warning('网格生成达到最大迭代次数');
            break;
        end
    end
    
    % 转换为x坐标：x = 1 - y
    x = 1 - y;
    
    % 反转网格点（使x从小到大）
    x = flip(x);
    
    % 确保包含端点
    if x(1) > 0
        x = [0, x];
    end
    if x(end) < 1
        x = [x, 1];
    end
    
    % 排序并去重
    x = unique(x);
    x = sort(x);
end