function val=solve_P(res0,V0,D0,invC1)
global Nt m
Nx=m;
It=eye(Nt);
invV0=It/V0;
res=StepAC(invC1,res0,m,Nt); 
Sa=StepAC(invV0,res,m,Nt);
Sb=StepB(diag(D0),Sa);
val=StepAC(V0,Sb,m,Nt);
end
