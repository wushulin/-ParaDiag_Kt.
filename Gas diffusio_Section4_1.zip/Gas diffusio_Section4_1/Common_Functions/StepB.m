function val=StepB(D0,Sa)
global A m dt Nt
Nx=m;
dW=zeros(Nx*Nt,1);
Ix=eye(Nx);
for n=1:Nt
    dW((n-1)*Nx+1:n*Nx,1)=(Ix+dt*D0(n)*A)\Sa((n-1)*Nx+1:n*Nx,1);
end
val=dW;
