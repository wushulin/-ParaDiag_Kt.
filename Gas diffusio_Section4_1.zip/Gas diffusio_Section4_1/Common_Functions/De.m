function val=De(t)
global  omg beta kapa
val=omg*kapa*t^(kapa-1)/((1+beta*t^kapa)^2);
end