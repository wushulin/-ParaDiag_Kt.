function val=K_times_U(u)
global Nt  m  A D dt theta  
Nx=m;
M=eye(m);
val0=zeros(Nx,Nt);
mat_u=reshape(u,Nx,Nt);
for n=1:Nt
    if n==1
        val0(:,n)=(M + dt*theta * D(n)*A)*mat_u(:,n);
    else
        val0(:,n)=(M + dt*theta * D(n)*A)*mat_u(:,n)-(M - dt*(1-theta) * D(n)*A) * mat_u(:,n-1);  
    end
end
val=reshape(val0,Nx*Nt,1);
end