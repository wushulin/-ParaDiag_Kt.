function val=StepAC(V,b,Nx,Nt)
val=zeros(Nx*Nt,1);
for n=1:Nt
    Z=zeros(Nx,1);
    for n1=1:Nt
        Z=Z+V(n,n1)*b((n1-1)*Nx+1:n1*Nx,1);
    end
    val((n-1)*Nx+1:n*Nx,1)=Z;
end
 
