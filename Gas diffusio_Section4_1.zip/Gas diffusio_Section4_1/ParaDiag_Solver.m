clc;
clear; 
current_path = fileparts(mfilename('fullpath'));
addpath(fullfile(current_path, 'Common_Functions'));
global h omg beta kapa dt theta flag_eig  alpha b r A Nt m D Tol Kmax
global flag_avg
flag_avg=1; % if you want to test Method-1 (implemented via GMRES) in Section 2.2 please set flag_avg=1
flag_eig=1;  % if you want to plot the eigenvalues of the preconditioned matrix please set flag_eig=1
Tol=1e-12;
Kmax=15;
Err=zeros(1,Kmax);
b=0; % b is the source term of the PDE, here b=0 and do not change it
r=1.015;
alpha=0.4;

T=2;
theta=1/2;
m=186;  
h=(r-1)/(r^m-1);
omg=1.78e-5;
beta=2.5e-4;
kapa=0.88;
dt=0.1/2;
Nt=round(T/dt);
t=0:dt:T;
A = getA(h,r); 
Im=speye(m);
D=zeros(1,Nt);
for n=1:Nt
    D(n)=De(theta*t(n+1)+(1-theta)*t(n));
end
B1=toeplitz([1;-1;zeros(Nt-2,1)],[1,zeros(1,Nt-1)]);
B2=toeplitz([theta;1-theta;zeros(Nt-2,1)],[theta,zeros(1,Nt-1)]);
C1=B1;C2=B2;
C1(1,Nt)=alpha*C1(2,1);
C2(1,Nt)=alpha*C2(2,1);
 if flag_eig==1
     fprintf('Compute the eigenvalues of the preconditioned matrix....\n');
    calA=kron(sparse(B1),Im)+dt*kron(sparse(diag(D))*sparse(B2),sparse(A));
    calP=kron(sparse(C1),Im)+dt*kron(sparse(diag(D))*sparse(C2),sparse(A));
    minftynorm(speye(m*Nt)-calP\calA,Nt,m);
    eigA=eig(full(A));
    eigPA=zeros(m*Nt,1);
    for jx=1:m
        cA=B1+dt*D*B2*eigA(jx);
        if alpha>0.01
            cP=C1+dt*D*C2*eigA(jx);
        else
             cP=C1+dt*mean(D)*C2*eigA(jx);
        end
        eigPA((jx-1)*Nt+1:jx*Nt)=eig(cP\cA);
    end
    figure(1);  
    plot(real(eigPA),1+0*real(eigPA),'+'); % imaginary part  of the eigenvalue is close to the machine precision
    shg 
    set(gca,'FontSize',15);
    xlabel('${\rm Re}(\mathcal{P}_\alpha^{-1}\mathcal{A})$','Interpreter','latex','FontSize',20);
    ylabel('${\rm Im}(\mathcal{P}_\alpha^{-1}\mathcal{A})$','Interpreter','latex','FontSize',20);
    title(['$\alpha=',num2str(alpha),'$'],'Interpreter','latex','FontSize',20);
    xlim([0.5,2.2]); 
    box off;
end

fprintf('Compute the reference solution....\n');
U_ref=zeros(m,Nt+1);
x=linspace(0,1,m)';
U0=ones(m,1);
U_ref(:,1)=U0;
AAA_b=zeros(m*Nt,1);
for n=1:Nt
    Dn=De(theta*t(n+1)+(1-theta)*t(n));
    U_ref(:,n+1)=(Im+dt*theta*Dn*A)\((Im-dt*(1-theta)*Dn*A)*U_ref(:,n)+dt*getg(h, theta*t(n+1)+(1-theta)*t(n), b,r));
    if n==1
        AAA_b((n-1)*m+1:n*m,1)=((Im-dt*(1-theta)*Dn*A)*U_ref(:,n)+dt*getg(h, theta*t(n+1)+(1-theta)*t(n), b,r));
    else
        AAA_b((n-1)*m+1:n*m,1)=dt*getg(h, theta*t(n+1)+(1-theta)*t(n), b,r);
    end
end
figure(2);
nn=min(round((0.1*1.2825.^(0:25))./dt),Nt);
U_ref(end,:)=0;
U_ref(end,1)=1;
for jn=1:length(nn)
    n=nn(jn); 
    plot3(t(n)*ones(m,1),x,U_ref(:,n),'LineWidth',1);shg
    hold on;
end
hold off;
set(gca,'FontSize',15);
xlabel('$t$','FontSize',20,'Interpreter','latex');
ylabel('$x$','FontSize',20,'Interpreter','latex');
zlabel('$u$','FontSize',20,'Interpreter','latex');
set(gca, 'XScale', 'log');


fprintf('Implement the ParaDiag solver....\n');
figure(3);
Uk=random('Uniform',-1,1,m*Nt,1);
k=1;
Ix=eye(m);It=eye(Nt);
U_ref_vec=reshape(U_ref(:,2:Nt+1),m*Nt,1);
Err(k)=max(max(abs(Uk-U_ref_vec))); 
invC1=inv(C1);
if flag_avg==1
    [V0,D0]=eig(invC1*mean(D)*C2);
    [U_ref0,FLAG,RELRES,ITER,RESVEC0]=gmres(@(u)K_times_U(u),AAA_b,100,1e-13,50,...
               @(u)solve_P(u,V0,D0,invC1),[],Uk);
    semilogy(0:length(RESVEC0)-1,2*RESVEC0/max(RESVEC0),'k-.o','MarkerSize',12,'LineWidth',1);
    set(gca,'FontSize',15);
    xlabel('Iteration Index: $k$','FontSize',20,'Interpreter','latex');
    ylabel('$\max_{n}\|\mathbf{u}^k_n-\mathbf{u}_n\|_\infty$','FontSize',20,'Interpreter','latex');
    xlim([0,Kmax]);
    set(gca,'xtick',0:2:Kmax);
    ylim([Tol,2.5]);
    set(gca,'ytick',10.^(-12:1:0));
    grid on;
    shg;
else
    [V0,D0]=eig(invC1*diag(D)*C2);
    invV0=It/V0;
    for k=1:Kmax-1
        res0=AAA_b-K_times_U(Uk);
        dU=solve_P(res0,V0,D0,invC1);
        Uk=Uk+dU;
        Err(k+1)=max(max(abs(Uk-U_ref_vec)));
        fprintf('%d-th Error is %2.15f\n',k,Err(k+1));
    end
    if alpha==0.4
        semilogy(0:Kmax-1,Err,'b-.s','MarkerSize',12,'LineWidth',1);shg
    elseif alpha==0.1
        semilogy(0:Kmax-1,Err,'m-.*','MarkerSize',12,'LineWidth',1);shg
    else
        semilogy(0:Kmax-1,Err,'r-.o','MarkerSize',12,'LineWidth',1);shg
        hold off;
    end
end
